This DAISY book is encrypted with a key from the National Library
Service, and may be read on appropriate reading devices with the key
installed.

For more information, see
http://openlibrary.org/help/faq/accessing#what-is-daisy or
https://nlsbard.loc.gov/
